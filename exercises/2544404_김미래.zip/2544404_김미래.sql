-- DB Final Project Skeleton

-- 1. CREATE TABLE

CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class VARCHAR(20),
    basis VARCHAR(50)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(50)
);


-- TODO: customer
-- cus_id(id), name(이름), cell(휴대폰), addr(주소), c_code(등급 코드)
--  등급코드는 (1: 최우수, 2: 우수, 3: 일반)으로 표현
CREATE TABLE customer(
    cus_id VARCHAR(15) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    cell CHAR(13) NOT NULL UNIQUE,
    addr VARCHAR(100),
    c_code NUMERIC(1) DEFAULT 3 CHECK (c_code IN (1, 2, 3))
);

-- TODO: staff
-- staff_id(사번), name(이름), birthday(생년월일), tel(연락처), salary(급여), t_code(담당엄부), hire_date(입사일)
--  담당업무는 (1: 여행상품관리, 2: 예악관리, 3: 관광버스배치관리, 4: 직원관리, 5: 고객관리)으로 표현
CREATE TABLE staff(
    staff_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday NUMERIC(6) NOT NULL,
    tel CHAR(12),
    salary NUMERIC(9),
    t_code NUMERIC(1) NOT NULL CHECK (t_code IN (1, 2, 3, 4, 5)),
    hire_date CHAR(8) NOT NULL
);

-- TODO: tour
-- tour_num(여행번호), departure(출발지), arrival(도착지), program(프로그램), start_dt(시작일시),
-- end_dt(종료일시), min_num(최소출발인원), max_num(최대인원), expense(여행경비), deposit(예약금), dept_yn(출발여부), staff_id(담당직원사번)
CREATE TABLE tour(
    tour_num CHAR(8) PRIMARY KEY,
    departure VARCHAR(50) NOT NULL,
    arrival VARCHAR(50) NOT NULL,
    program VARCHAR(100),
    start_dt DATE NOT NULL,
    end_dt DATE NOT NULL,
    min_num NUMERIC(2),
    max_num NUMERIC(2),
    expense NUMERIC(7) NOT NULL,
    deposit NUMERIC(6),
    dept_yn CHAR(1) DEFAULT 'N',
    staff_id NUMERIC(5),

    FOREIGN KEY (staff_id) REFERENCES staff(staff_id)
);

-- TODO: reserve
-- cus_id(고객 id), tour_num(여행번호), res_date(예약일자), dep_yn(예약금결제여부), exp_yn(여행경비결제여부)
CREATE TABLE reserve(
    cus_id VARCHAR(15),
    tour_num CHAR(8),
    res_date CHAR(8) DEFAULT TO_CHAR(CURRENT_DATE, 'YYYYMMDD'), -- 현재 날짜를 'YYYYMMDD' 형식으로 가져온 후 CHAR 타입으로 변환.
    dep_yn CHAR(1) DEFAULT 'N',
    exp_yn CHAR(1) DEFAULT 'N',

    PRIMARY KEY (cus_id, tour_num),
    FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
    FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- BONUS TABLES (Optional)

-- TODO: driver
-- driver_id(기사 id), name(이름), birthday(생년월일), cell(휴대폰), pay(시급), cont_date(계약일), cont_term(계약기간)
CREATE TABLE driver(
    driver_id NUMERIC(5) PRIMARY KEY,
    name VARCHAR(20) NOT NULL,
    birthday CHAR(6) NOT NULL,
    cell CHAR(13) NOT NULL,
    pay NUMERIC(5) DEFAULT 15000,
    cont_date CHAR(8),
    cont_term CHAR(8)
);

-- TODO: tour_bus
-- bus_id(차량번호), seat(좌석수), del_yesr(출고년도)
CREATE TABLE tour_bus(
    bus_id NUMERIC(2) PRIMARY KEY,
    seat NUMERIC(2),
    del_yesr NUMERIC(4)
);

-- TODO: assign_driver
-- tour_num(여행번호), driver_id(기사 id), work_hour(근무시간)
CREATE TABLE assign_driver(
    tour_num CHAR(8) PRIMARY KEY,
    driver_id NUMERIC(5),
    work_hour NUMERIC(3),

    FOREIGN KEY (tour_num) REFERENCES tour(tour_num),
    FOREIGN KEY (driver_id) REFERENCES driver(driver_id)
);

-- TODO: assign_bus
-- tour_num(여행번호), bus_id(차량번호)
CREATE TABLE assign_bus(
    tour_num CHAR(8) PRIMARY KEY,
    bus_id   NUMERIC(2),

    FOREIGN KEY (tour_num) REFERENCES tour (tour_num),
    FOREIGN KEY (bus_id) REFERENCES tour_bus (bus_id)
);

-- 2. INSERT DATA

-- TODO: Insert at least 5 rows into each table
-- customer
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
    ('CUST00000000001', '김민수', '010-1111-1111', '서울시 강남구', 1),
    ('CUST00000000002', '이서연', '010-2222-2222', '부산시 해운대구', 2),
    ('CUST00000000003', '박지훈', '010-3333-3333', '대전시 유성구', 3),
    ('CUST00000000004', '최유진', '010-4444-4444', '광주시 북구', 2),
    ('CUST00000000005', '정하늘', '010-5555-5555', '인천시 남동구', 3);

-- staff
INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
    (10001, '홍길동', 900101, '02-1111-1111', 32000000, 1, '20200101'),
    (10002, '김영희', 920305, '02-2222-2222', 34000000, 2, '20210315'),
    (10003, '이철수', 880715, '02-3333-3333', 36000000, 3, '20190520'),
    (10004, '박민지', 950912, '02-4444-4444', 30000000, 4, '20220701'),
    (10005, '최준호', 910430, '02-5555-5555', 38000000, 5, '20181110');

-- tour
INSERT INTO tour (
    tour_num, departure, arrival, program, start_dt, end_dt,
    min_num, max_num, expense, deposit, dept_yn, staff_id
) VALUES
      ('TOUR0001', '서울', '제주', '제주 2박 3일 여행', '2026-07-01', '2026-07-03', 10, 30, 500000, 100000, 'N', 10001),
      ('TOUR0002', '부산', '경주', '경주 역사문화 여행', '2026-07-05', '2026-07-06', 8, 25, 250000, 50000, 'N', 10002),
      ('TOUR0003', '대전', '강릉', '강릉 바다 여행', '2026-06-08', '2026-06-11', 12, 35, 420000, 80000, 'Y', 10003),
      ('TOUR0004', '광주', '여수', '여수 밤바다 여행', '2026-06-02', '2026-06-05', 10, 28, 300000, 60000, 'Y', 10004),
      ('TOUR0005', '인천', '속초', '속초 힐링 여행', '2026-07-20', '2026-07-22', 15, 40, 450000, 90000, 'N', 10005);

-- reverse
INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
    ('CUST00000000001', 'TOUR0001', '20260601', 'Y', 'N'),
    ('CUST00000000002', 'TOUR0002', '20260602', 'Y', 'Y'),
    ('CUST00000000003', 'TOUR0003', '20260603', 'N', 'N'),
    ('CUST00000000004', 'TOUR0004', '20260604', 'Y', 'N'),
    ('CUST00000000005', 'TOUR0005', '20260605', 'N', 'N');

-- driver
INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
    (20001, '강민호', '850101', '010-6666-6666', 16000, '20260101', '20261231'),
    (20002, '오세훈', '870215', '010-7777-7777', 15500, '20260101', '20261231'),
    (20003, '한지민', '900718', '010-8888-8888', 17000, '20260101', '20261231'),
    (20004, '윤도현', '830930', '010-9999-9999', 16500, '20260101', '20261231'),
    (20005, '서지수', '920412', '010-0000-0000', 15000, '20260101', '20261231');

-- tour_bus
INSERT INTO tour_bus (bus_id, seat, del_yesr) VALUES
    (1, 45, 2020),
    (2, 40, 2021),
    (3, 35, 2019),
    (4, 45, 2022),
    (5, 30, 2023);

-- assign_driver
INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
    ('TOUR0001', 20001, 8),
    ('TOUR0002', 20002, 6),
    ('TOUR0003', 20003, 9),
    ('TOUR0004', 20004, 7),
    ('TOUR0005', 20005, 8);

-- assign_bus
INSERT INTO assign_bus (tour_num, bus_id) VALUES
    ('TOUR0001', 1),
    ('TOUR0002', 2),
    ('TOUR0003', 3),
    ('TOUR0004', 4),
    ('TOUR0005', 5);

-- assign_driver
INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
    ('TOUR0001', 20001, 8),
    ('TOUR0002', 20002, 6),
    ('TOUR0003', 20003, 9),
    ('TOUR0004', 20004, 7),
    ('TOUR0005', 20005, 8);

-- 3. INDEX

-- TODO: CREATE INDEX
-- 여행상품 도착지 인덱스
CREATE INDEX tour_arrival_idx
    ON tour(arrival);

-- 도착지로 여행상품 검색
SELECT *
FROM tour
WHERE arrival = '제주';

-- 운전기사 이름 인덱스
CREATE INDEX driver_name_idx
    ON driver(name);

-- 운전기사 이름으로 검색
SELECT *
FROM driver
WHERE name = '강민호';

-- 운전기사 이름 오름차순 정렬
SELECT *
FROM driver
ORDER BY name ASC;

-- 4. TEST QUERIES

-- Customer Grade Search
SELECT cus_id, name, c_code FROM customer;

-- Employee Task Search
SELECT staff_id, name, t_code FROM staff;

-- Tour Reservation Search
SELECT t.tour_num AS 여행번호,r.cus_id AS 고객번호, t.departure AS 출발지, t.arrival AS 도착지, t.start_dt AS 시작일시, t.end_dt AS 종료일시
FROM tour t JOIN reserve r
ON t.tour_num = r.tour_num;

-- Assigned Driver Search
SELECT t.tour_num AS 여행번호, ad.driver_id AS 버스_기사_번호, d.name AS 버스_기사_이름, t.departure AS 출발지, t.arrival AS 도착지
FROM tour t
JOIN assign_driver ad
ON t.tour_num = ad.tour_num
JOIN driver d
ON ad.driver_id = d.driver_id;

-- INSERT example
-- New customer register
INSERT INTO customer VALUES
    ('CUST00000000006', '김미래', '010-1234-5678', '서울시 송파구', 1);

SELECT * FROM customer;

-- UPDATE example
-- Employee salary update
UPDATE staff
SET salary = '50000000'
WHERE staff_id = '10004';

SELECT * FROM staff;

-- DELETE example
-- Reservation delete
DELETE FROM reserve
WHERE cus_id = 'CUST00000000003'
AND tour_num = 'TOUR0003';

SELECT * FROM reserve;

